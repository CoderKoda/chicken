(display "abc")
