(DISPLAY "abc")
